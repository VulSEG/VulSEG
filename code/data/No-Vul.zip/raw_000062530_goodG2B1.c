static void FUN1()
{
    int VAR1;
    
    VAR1 = -1;
    switch(5)
    {
    case 6:
        
        FUN2("");
        break;
    default:
        
        VAR1 = 7;
        break;
    }
    switch(7)
    {
    case 7:
    {
        int VAR2;
        int VAR3[10] = { 0 };
        
        if (VAR1 >= 0)
        {
            VAR3[VAR1] = 1;
            
            for(VAR2 = 0; VAR2 < 10; VAR2++)
            {
                FUN3(VAR3[VAR2]);
            }
        }
        else
        {
            FUN2("");
        }
    }
    break;
    default:
        
        FUN2("");
        break;
    }
}