static void FUN1()
{
    int VAR1;
    
    VAR1 = -1;
    
    VAR1 = 7;
    VAR2 = 1; 
    FUN2(VAR1);
}