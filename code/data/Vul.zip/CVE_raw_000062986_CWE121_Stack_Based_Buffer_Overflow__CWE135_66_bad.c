void FUN1()
{
    void * VAR1;
    void * VAR2[5];
    VAR1 = NULL;
    
    VAR1 = (void *)VAR3;
    
    VAR2[2] = VAR1;
    FUN2(VAR2);
}