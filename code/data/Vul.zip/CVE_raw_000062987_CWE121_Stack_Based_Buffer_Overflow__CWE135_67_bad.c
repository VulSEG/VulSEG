void FUN1()
{
    void * VAR1;
    CWE121_Stack_Based_Buffer_Overflow__CWE135_67_structType VAR2;
    VAR1 = NULL;
    
    VAR1 = (void *)VAR3;
    VAR2.VAR4 = VAR1;
    FUN2(VAR2);
}