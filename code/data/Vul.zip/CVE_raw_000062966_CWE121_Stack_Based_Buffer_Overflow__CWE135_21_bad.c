void FUN1()
{
    void * VAR1;
    VAR1 = NULL;
    
    VAR1 = (void *)VAR2;
    VAR3 = 1; 
    FUN2(VAR1);
}