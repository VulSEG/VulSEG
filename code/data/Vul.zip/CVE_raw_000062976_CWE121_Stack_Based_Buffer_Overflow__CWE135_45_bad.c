void FUN1()
{
    void * VAR1;
    VAR1 = NULL;
    
    VAR1 = (void *)VAR2;
    VAR3 = VAR1;
    FUN2();
}