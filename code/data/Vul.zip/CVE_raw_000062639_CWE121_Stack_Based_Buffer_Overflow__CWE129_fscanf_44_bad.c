void FUN1()
{
    int VAR1;
    
    void (*VAR2) (int) = VAR3;
    
    VAR1 = -1;
    
    fscanf(stdin, "", &VAR1);
    
    FUN2(VAR1);
}