void FUN1()
{
    int VAR1;
    
    VAR1 = -1;
    
    fscanf(stdin, "", &VAR1);
    FUN2(VAR1);
}